package com.main;

import com.model.Employee;

public class MainLoop {

	public static void main(String[] args)
	{
// print the name 5 times
		for (int i = 0; i < 5; i++) 
		{
			System.out.println("Nikitha");
		}
	}
}
	
	
	

