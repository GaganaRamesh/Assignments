package com.model;

public class Employee 
{
private int empId;
private String empName;
private String address;

public void employeeDetails(int empld, String empName, String address)
	{
		System.out.println("Employee ID is " +empId);
		System.out.println("Employee name is " +empName);
		System.out.println("Employee address is " +address);
		
	}
}
