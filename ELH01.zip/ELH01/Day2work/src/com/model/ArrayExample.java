package com.model;

public class ArrayExample 
{
int arr[] = {1,2,3,4};

}
