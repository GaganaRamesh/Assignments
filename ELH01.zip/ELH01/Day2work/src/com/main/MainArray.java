package com.main;

public class MainArray {

	public static void main(String[] args) {
		int arr[] = { 1, 2, 3, 4 };
		for (int arrayOfElements : arr) 
		{			
			System.out.println();
		}
	}

}
